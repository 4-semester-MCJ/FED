namespace CarWorkshopAwesomeApp.Views;

public partial class TaskBookingPage : ContentPage
{
    public TaskBookingPage()
    {
        InitializeComponent();
    }
}

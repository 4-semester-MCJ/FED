namespace CarWorkshopAwesomeApp.Views;

public partial class InvoicePage : ContentPage
{
    public InvoicePage()
    {
        InitializeComponent();
    }
}
